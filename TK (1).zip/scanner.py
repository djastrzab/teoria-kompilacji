import sys
import ply.lex as lex

reserved = {
    'if': 'IF',
    'else': 'ELSE',
    'while': 'WHILE',
    'for': 'FOR',
    'break': 'BREAK',
    'continue': 'CONTINUE',
    'return': 'RETURN',
    'eye': 'EYE',
    'zeros': 'ZEROS',
    'ones': 'ONES',
    'print': 'PRINT',
}

dots = {
    '\.\+': 'DOTADD',
    '\.-': 'DOTSUB',
    '\.\*': 'DOTMUL',
    '\./': 'DOTDIV'
}

tokens = [
             'ADD', 'SUB', 'MUL', 'DIV',
             'ADDASSIGN', 'SUBASSIGN', 'MULASSIGN', 'DIVASSIGN',
             'ASSIGN',
             'LESS', 'GREATER', 'LESSEQ', 'GREATEREQ', 'INEQ', 'EQ',
             'LPAREN', 'RPAREN',
             'LSQPAREN', 'RSQPAREN',
             'LCPAREN', 'RCPAREN',
             'RANGE', 'TRANSPOSE',
             'COMMA', 'SEMICOLON',
             'ID',
             'INTEGER', 'FLOATING', 'STRING'
         ] + list(reserved.values()) + list(dots.values())

t_ADD = r'\+'
t_SUB = r'-'
t_MUL = r'\*'
t_DIV = r'/'
t_DOTADD = r'\.\+'
t_DOTSUB = r'\.-'
t_DOTMUL = r'\.\*'
t_DOTDIV = r'\./'
t_ASSIGN = r'='
t_ADDASSIGN = r'\+='
t_SUBASSIGN = r'-='
t_MULASSIGN = r'\*='
t_DIVASSIGN = r'/='
t_LESS = r'<'
t_GREATER = r'>'
t_LESSEQ = r'<='
t_GREATEREQ = r'>='
t_INEQ = r'!='
t_EQ = r'=='
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LSQPAREN = r'\['
t_RSQPAREN = r'\]'
t_LCPAREN = r'\{'
t_RCPAREN = r'\}'
t_RANGE = r'\:'
t_TRANSPOSE = r'\''
t_COMMA = r'\,'
t_SEMICOLON = r'\;'
t_INTEGER = r'0|([1-9][0-9]*)'
t_STRING = r'"(\\"|.)*"'

t_ignore = ' \t'

def t_FLOATING(t):
    r'((0|([1-9][0-9]*))?\.[0-9]+((e|E)(-?)(0|([1-9][0-9]*)))?)|((0|([1-9][0-9]*))\.[0-9]*((e|E)(-?)(0|([1-9][0-9]*)))?)'
    return t

def t_ID(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    t.type = reserved.get(t.value, 'ID')
    return t

def t_COMMENT(t):
    r'\#.*((?=\n)|$)'

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)


def find_column(input, token):
    last_cr = input.rfind('\n', 0, token.lexpos)
    if last_cr < 0:
        last_cr = 0
    column = (token.lexpos - last_cr)
    return column


def t_error(t):
    #column = find_column(text, t)
    print("line %d: illegal character '%s'" % (t.lineno, t.value[0]))
    t.lexer.skip(1)

lexer = lex.lex()