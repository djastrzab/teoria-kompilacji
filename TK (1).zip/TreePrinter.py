from __future__ import print_function
import AST

def addToClass(cls):

    def decorator(func):
        setattr(cls,func.__name__,func)
        return func
    return decorator

class TreePrinter:

    @addToClass(AST.Node)
    def printTree(self, indent=0):
        raise Exception("printTree not defined in class " + self.__class__.__name__)

    @addToClass(AST.InstructionSequence)
    def printTree(self, indent=0):
        for instruction in self.instructions:
            instruction.printTree(indent)

    @addToClass(AST.BinaryExpression)
    def printTree(self, indent=0):
        print("| "*indent + self.op)
        self.left.printTree(indent+1)
        self.right.printTree(indent+1)

    @addToClass(AST.Pair)
    def printTree(self, indent=0):
        print("| " * indent + 'PAIR')
        self.v1.printTree(indent + 1)
        self.v2.printTree(indent + 1)

    @addToClass(AST.Variable)
    def printTree(self, indent=0):
        print("| "*indent + self.name)

    @addToClass(AST.LeftUnaryExpression)
    def printTree(self, indent=0):
        print("| " * indent + self.op)
        self.subop.printTree(indent + 1)

    @addToClass(AST.RightUnaryExpression)
    def printTree(self, indent=0):
        print("| " * indent + self.op)
        self.subop.printTree(indent + 1)

    @addToClass(AST.SpecialFunction)
    def printTree(self, indent=0):
        print("| "*indent + self.name)
        self.arg0.printTree(indent + 1)
        if self.arg1 is not None:
            self.arg1.printTree(indent + 1)

    @addToClass(AST.Integer)
    def printTree(self, indent=0):
        print("| " * indent + self.value)

    @addToClass(AST.Float)
    def printTree(self, indent=0):
        print("| " * indent + self.value)

    @addToClass(AST.String)
    def printTree(self, indent=0):
        print("| " * indent + self.value)

    @addToClass(AST.Array)
    def printTree(self, indent=0):
        print("| " * indent + '[]')
        for element in self.elements:
            element.printTree(indent + 1)

    @addToClass(AST.PrintInstruction)
    def printTree(self, indent=0):
        print("| " * indent + 'print')
        for arg in self.args:
            arg.printTree(indent + 1)

    @addToClass(AST.IfElseExpression)
    def printTree(self, indent=0):
        print("| " * indent + 'if')
        self.expr.printTree(indent+1)
        self.if_block.printTree(indent+1)
        if self.else_block is not None:
            self.else_block.printTree(indent+1)

    @addToClass(AST.Noop)
    def printTree(self, indent=0):
        pass

    @addToClass(AST.WhileExpression)
    def printTree(self, indent=0):
        print("| " * indent + 'while')
        self.expr.printTree(indent + 1)
        self.while_block.printTree(indent + 1)

    @addToClass(AST.ForExpression)
    def printTree(self, indent=0):
        print("| " * indent + 'for')
        self.variable.printTree(indent + 1)
        self.range.printTree(indent + 1)
        self.for_block.printTree(indent + 1)

    @addToClass(AST.BreakInstruction)
    def printTree(self, indent=0):
        print("| " * indent + 'break')

    @addToClass(AST.ContinueInstruction)
    def printTree(self, indent=0):
        print("| " * indent + 'continue')

    @addToClass(AST.ReturnInstruction)
    def printTree(self, indent=0):
         print("| " * indent + 'return')
         self.expr.printTree(indent + 1)