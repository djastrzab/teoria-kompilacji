
class Type:
    def __init__(self, type_name, constant_value = None):
        self.type_name = type_name
        self.constant_value = constant_value

    def is_constant(self):
        return self.constant_value is not None

    def get_constant(self):
        return self.constant_value

    def name(self):
        return self.type_name

    def is_type(self, type_name):
        return self.type_name == type_name

    def typename(self):
        return self.__class__.__name__

    def __eq__(self, other):
        return self.typename() == other.typename()

    def __hash__(self):
        return hash(self.typename())

    def convertible_to(self, other):
        return self == other

class Int(Type):
    def __init__(self, value = None):
        super(Int, self).__init__(self.__class__.__name__, value)

    def convertible_to(self, other):
        if other is Float:
            return True
        return self == other

class Variable(Type):
    def __init__(self, name):
        super(Variable, self).__init__(self.__class__.__name__, None)
        self.type = None
        self.name = name

    def __str__(self):
        return self.name

class Pair(Type):
    def __init__(self, subtype : Type, v1 = None, v2 = None):
        super(Pair, self).__init__(self.__class__.__name__, (v1, v2))
        self.st = subtype

    def subtype(self):
        return self.st

class Float(Type):
    def __init__(self, value = None):
        super(Float, self).__init__(self.__class__.__name__, value)

    def convertible_to(self, other):
        if other is Int:
            return True
        return self == other

class Range(Type):
    def __init__(self, subtype : Type):
        super(Range, self).__init__(self.__class__.__name__, None)
        self.st = subtype

    def subtype(self):
        return self.st

class String(Type):
    def __init__(self, value = None):
        super(String, self).__init__(self.__class__.__name__, value)

class Array(Type):
    def __init__(self, subtype : Type, length = None):
        super(Array, self).__init__(self.__class__.__name__, None)
        self.len = length
        self.st = subtype

    def subtype(self):
        return self.st

    def length(self):
        return self.len

class Matrix(Type):
    def __init__(self, subtype : Type, rows = None, cols = None):
        super(Matrix, self).__init__(self.__class__.__name__, None)
        self.r = rows
        self.c = cols
        self.st = subtype

    def subtype(self):
        return self.st

    def rows(self):
        return self.r

    def cols(self):
        return self.c

tint = Int()
tfloat = Float()
tstring = String()
tarray = Array(None)
tmatrix = Matrix(None)
tvariable = Variable(None)
tpair = Pair(None)
trange = Range(None)


class OpType:
    types = [tint, tfloat, tstring, tarray, tmatrix]
    operators = ['+', '-', '*', '/', '<', '>', '==', '!=', '>=', '<=', '=', '+=', '-=', '*=', '/=', '.+', '.-', '.*', './']
    ttype = None

    def __init__(self):
        self.ttype = dict((op, dict((type1, dict(dict((type2, None) for type2 in self.types))) for type1 in self.types)) for op in self.operators)
        self.addAssign()
        self.addCompoundAssign()
        self.addArithmeticPrimitive()
        self.addDotArithmetic()
        self.addStringOps()
        self.addComparisons()

    def addAssign(self):
        for type1 in self.types:
            for type2 in self.types:
                self.ttype['='][type1][type2] = type1

    def addCompoundAssign(self):
        for op in '+=', '-=', '*=', '/=':
            self.ttype[op][tint][tfloat] = tint
            self.ttype[op][tfloat][tint] = tfloat
            self.ttype[op][tint][tint] = tint
            self.ttype[op][tfloat][tfloat] = tfloat

        self.ttype['+='][tarray][tarray] = tarray
        self.ttype['+='][tmatrix][tmatrix] = tmatrix
        self.ttype['-='][tmatrix][tmatrix] = tmatrix
        self.ttype['*='][tmatrix][tmatrix] = tmatrix

    def addArithmeticPrimitive(self):
        for op in '+-*/':
            self.ttype[op][tint][tfloat] = tfloat
            self.ttype[op][tfloat][tint] = tfloat
            self.ttype[op][tint][tint] = tint
            self.ttype[op][tfloat][tfloat] = tfloat

        self.ttype['+'][tarray][tarray] = tarray
        self.ttype['+'][tmatrix][tmatrix] = tmatrix
        self.ttype['-'][tmatrix][tmatrix] = tmatrix
        self.ttype['*'][tmatrix][tmatrix] = tmatrix
        self.ttype['*'][tmatrix][tarray] = tarray
        self.ttype['*'][tarray][tmatrix] = tarray

    def addDotArithmetic(self):
        for op in '.+', '.-', '.*', './':
            self.ttype[op][tarray][tarray] = tarray
            self.ttype[op][tmatrix][tmatrix] = tmatrix

    def addStringOps(self):
        self.ttype['+'][tstring][tstring] = tstring
        self.ttype['*'][tstring][tint] = tstring

    def addComparisons(self):
        for op in '<', '>', '==', '!=', '>=', '<=':
            self.ttype[op][tint][tint] = tint
            self.ttype[op][tint][tfloat] = tint
            self.ttype[op][tfloat][tint] = tint
            self.ttype[op][tfloat][tfloat] = tint
            self.ttype[op][tstring][tstring] = tint

        for op in '==', '!=':
            self.ttype[op][tmatrix][tmatrix] = tint
            self.ttype[op][tarray][tarray] = tint

    def getOpType(self, op, left, right):
        if op in self.ttype:
            if left in self.ttype[op]:
                if right in self.ttype[op][left]:
                    return self.ttype[op][left][right]
        return None